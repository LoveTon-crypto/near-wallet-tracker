# NEAR Wallet Tracker Bot

Telegram-бот: добавляешь кошелёк NEAR, даёшь имя — бот **в реальном времени** присылает всё, что этот кошелёк делает.

Бесплатно и без API-ключей: события идут по WebSocket из [Intear API](https://docs.intear.tech/docs/events-api/), названия/decimals токенов — из NEAR RPC.

## Что умеет
- `/add` — добавить кошелёк (пошагово), или сразу `/add alice.near Кит #1`
- `/list` — список кошельков с кнопками удаления
- `/remove Кит #1` — удалить по имени или адресу
- Уведомления:
  - 🟢 **Купил** — потратил NEAR/wNEAR и получил токен, сумма в $ и через какой DEX/пул/мемпад
  - 🔴 **Продал** — отдал токен и получил NEAR
  - 🔄 **Своп** — токен на токен
  - 📥/📤 переводы токенов и NEAR (от кого / кому)
  - ссылка на транзакцию в NearBlocks
- wNEAR и NEAR считаются как одно, поэтому wrap/unwrap не спамит
- При добавлении старая история пропускается — только новые действия
- После перезапуска бот догоняет пропущенное (запоминает последнее событие)
- Отвечает на русском или английском по языку Telegram

## Запуск на VPS (Ubuntu)
```bash
git clone https://github.com/<твой-аккаунт>/near-wallet-tracker.git
cd near-wallet-tracker
sudo apt install -y python3-venv
python3 -m venv venv && source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env && nano .env    # вставить BOT_TOKEN
python bot.py                         # проверить, что запускается
```

### Автозапуск (systemd)
```bash
sudo nano /etc/systemd/system/near-tracker.service
```
```ini
[Unit]
Description=NEAR Wallet Tracker Bot
After=network.target

[Service]
WorkingDirectory=/root/near-wallet-tracker
ExecStart=/root/near-wallet-tracker/venv/bin/python bot.py
Restart=always

[Install]
WantedBy=multi-user.target
```
```bash
sudo systemctl daemon-reload
sudo systemctl enable --now near-tracker
journalctl -u near-tracker -f        # логи
```

Обновление: `git pull && sudo systemctl restart near-tracker`

## Про лимиты
Intear API сейчас в бете и бесплатный, ключ не нужен. Один WebSocket держит до 50 кошельков,
бот сам открывает дополнительные соединения, если кошельков больше.
Intear предупреждает, что после беты может появиться оплата (система «кредитов») — если так будет,
бот можно перевести на другой источник.

## Обновление со старой версии
Просто `git pull` и рестарт — список кошельков (`tracker.db`) сохранится.
